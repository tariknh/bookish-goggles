#pragma once

#ifndef OPTION1_H
#define OPTION1_H

int RunApp();


#endif // OPTION1_H
